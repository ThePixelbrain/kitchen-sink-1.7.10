#!/bin/bash

if [ -n "$JAVA8_HOME" ]; then
	export JAVA_HOME=$JAVA8_HOME
fi
v=$(env -u_JAVA_OPTIONS $JAVA_HOME/bin/java -Xint -version 2>&1 | head -n1 |cut -d\" -f2)
if [[ ! "$v" =~ ^1\.8\. ]]; then
	echo "Found Java $v - This modpack requires Java 8. Please install it and set JAVA8_HOME to a path to it." 1>&2
	exit 1
fi

# unsup has to be run separately to grab forge/mc
$JAVA_HOME/bin/java -jar unsup.jar server
$JAVA_HOME/bin/java -Xms4G -Xmx8G -XX:+UseG1GC -Dsun.rmi.dgc.server.gcInterval=2147483646 -XX:+UnlockExperimentalVMOptions -XX:G1NewSizePercent=20 -XX:G1ReservePercent=20 -XX:MaxGCPauseMillis=50 -XX:G1HeapRegionSize=32M -XX:+UseStringDeduplication -Dlog4j.configurationFile=log4j2_17-111.xml -jar forge.jar nogui
